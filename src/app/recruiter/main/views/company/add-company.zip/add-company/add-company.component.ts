import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { AddCompany, AddCompanyFull } from 'src/app/models/company';
import { CountryListService } from 'src/app/services/country-list.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.scss'],
})
export class AddCompanyComponent implements OnInit {
  AddCompanyForm!: FormGroup;
  countryList!: import('c:/Users/zwarttech/Desktop/jobid-fork/jobid/src/app/models/country').Country[];

  constructor(
    private _fb: FormBuilder,
    private _countryListSvc: CountryListService
  ) {}

  ngOnInit(): void {
    this.onGetCountryList();
    this.buildForm();
    console.log('formArray(): ', this.formArray.controls[0]);
  }

  buildForm() {
    this.AddCompanyForm = this._fb.group({
      CompanyName: '',
      EmailAddress: '',
      Address: '',
      Location: '',
      CompanySize: '',
      Website: '',
      VATRegistration: '',
      CompanyLogo: '',
      Description: '',
      Contacts: this._fb.array([this.initItemRows()]),
      InviteCompany: false,
    });
    return this.AddCompanyForm;
  }

  get formArray() {
    return this.AddCompanyForm.get('Contacts') as FormArray;
  }
  initItemRows(): FormGroup {
    return this._fb.group({
      ContactFirstName: '',
      ContactLastName: '',
      ContactEmail: '',
      ContactMobileNumber: '',
    });
  }

  onGetCountryList() {
    this.countryList = this._countryListSvc.getCountryList();
  }

  // internationalNumber
  addNewRow() {
    this.formArray.push(this.initItemRows());
  }

  deleteRow(index: number) {
    this.formArray.removeAt(index);
  }

  onSubmit() {
    let data: any = {
      CompanyName: this.AddCompanyForm.value.CompanyName,
      EmailAddress: this.AddCompanyForm.value.EmailAddress,
      Address: this.AddCompanyForm.value.Address,
      Location: this.AddCompanyForm.value.Location,
      CompanySize: this.AddCompanyForm.value.CompanySize,
      Website: this.AddCompanyForm.value.Website,
      VATRegistration: this.AddCompanyForm.value.VATRegistration,
      CompanyLogo: this.AddCompanyForm.value.CompanyLogo,
      Description: this.AddCompanyForm.value.Description,
      // Contacts: this.AddCompanyForm.value.Contacts,
      Contacts: this.contactDetails(this.AddCompanyForm.value.Contacts),
      InviteCompany: this.AddCompanyForm.value.InviteCompany,
    };

    if (data.Contacts.length > 1) {
      let newData: AddCompanyFull = {
        Name: data.CompanyName,
        ContactDetails: data.CompanyName,
        Address: data.Address,
        Description: data.Description,
        Location: data.Location,
        Size: data.CompanySize,
        Website: data.Website,
        VATReistration: data.VATRegistration,
        EmailAddress: data.EmailAddress,
        LogoUrl: data.CompanyLogo,
        UpdatedBy: '',
        ContactPerson1_FirstName: data.Contacts[0].ContactFirstName,
        ContactPerson1_LastName: data.Contacts[0].ContactLastName,
        ContactPerson1_Email: data.Contacts[0].ContactEmail,
        ContactPerson1_Mobile: data.Contacts[0].ContactMobileNumber,
        ContactPerson1_Role: '',
        ContactPerson2_FirstName: data.Contacts[1]?.ContactFirstName,
        ContactPerson2_LastName: data.Contacts[1]?.ContactLastName,
        ContactPerson2_Email: data.Contacts[1]?.ContactEmail,
        ContactPerson2_Mobile: data.Contacts[1]?.ContactMobileNumber,
        ContactPerson2_Role: '',
      };
      console.log('AddCompanyForm newData full: ', newData);
    } else {
      let newData: AddCompany = {
        Name: data.CompanyName,
        ContactDetails: data.CompanyName,
        Address: data.Address,
        Description: data.Description,
        Location: data.Location,
        Size: data.CompanySize,
        Website: data.Website,
        VATReistration: data.VATRegistration,
        EmailAddress: data.EmailAddress,
        LogoUrl: data.CompanyLogo,
        UpdatedBy: '',
        ContactPerson1_FirstName: data.Contacts[0].ContactFirstName,
        ContactPerson1_LastName: data.Contacts[0].ContactLastName,
        ContactPerson1_Email: data.Contacts[0].ContactEmail,
        ContactPerson1_Mobile: data.Contacts[0].ContactMobileNumber,
        ContactPerson1_Role: '',
      };
      console.log('AddCompanyForm newData half: ', newData);
    }
    console.log('AddCompanyForm: ', this.AddCompanyForm.value);
    console.log('AddCompanyForm data: ', data);
  }

  contactDetails(contacts: any[]) {
    let newList: any = [];
    contacts.forEach((contact: any) => {
      let data = {
        ContactFirstName: contact.ContactFirstName,
        ContactLastName: contact.ContactLastName,
        ContactEmail: contact.ContactEmail,
        ContactMobileNumber: contact.ContactMobileNumber?.internationalNumber,
      };
      newList.push(data);
    });
    return newList;
  }
}
